const API = "http://localhost:5000";

function showLoading(id) {
  const el    = document.getElementById(id);
  el.className = "result warn";
  el.innerHTML = "⏳ Scanning... please wait.";
  el.classList.remove("hidden");
}

function showResult(id, data) {
  const el       = document.getElementById(id);
  const isThreat = data.is_threat;
  const level    = data.block?.level || "none";

  if (level === "hard" || level === "soft") el.className = "result threat";
  else if (level === "warn")                el.className = "result warn";
  else                                      el.className = "result safe";

  let html = `<strong>Verdict:</strong> ${data.verdict}<br/><br/>`;
  if (data.risk_score !== undefined)
    html += `<strong>Risk Score:</strong> ${data.risk_score}%<br/>`;
  if (data.block?.message)
    html += `<strong>Action:</strong> ${data.block.message}<br/>`;
  if (data.matched_keywords?.length)
    html += `<strong>⚠️ Keywords:</strong> ${data.matched_keywords.join(", ")}<br/>`;
  if (data.sensitive_data && Object.keys(data.sensitive_data).length) {
    html += `<strong>🔐 Sensitive Data:</strong><br/>`;
    for (const [t, v] of Object.entries(data.sensitive_data))
      html += `&nbsp;&nbsp;• ${t}: ${v.join(", ")}<br/>`;
  }
  if (data.transcript || data.transcription)
    html += `<br/><strong>📝 Transcript:</strong> "${data.transcript || data.transcription}"<br/>`;
  if (data.extracted_text)
    html += `<br/><strong>📄 Extracted Text:</strong> "${data.extracted_text}"<br/>`;

  el.innerHTML = html;
}

function showError(id, msg) {
  const el     = document.getElementById(id);
  el.className  = "result threat";
  el.innerHTML  = `❌ Error: ${msg}`;
}

async function scanText() {
  const text = document.getElementById("textInput").value.trim();
  if (!text) { alert("Please enter some text."); return; }
  showLoading("textResult");
  try {
    const res  = await fetch(`${API}/detect/text`, {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({text})
    });
    showResult("textResult", await res.json());
  } catch(e) { showError("textResult", "Cannot connect to server."); }
}

async function scanImage() {
  const file = document.getElementById("imageInput").files[0];
  if (!file) { alert("Please select an image."); return; }
  showLoading("imageResult");
  const fd = new FormData();
  fd.append("file", file);
  try {
    const res = await fetch(`${API}/detect/image`, {method:"POST", body:fd});
    showResult("imageResult", await res.json());
  } catch(e) { showError("imageResult", "Cannot connect to server."); }
}

async function scanVoice() {
  const file = document.getElementById("voiceInput").files[0];
  if (!file) { alert("Please select an audio file."); return; }
  showLoading("voiceResult");
  const fd = new FormData();
  fd.append("file", file);
  try {
    const res = await fetch(`${API}/detect/voice`, {method:"POST", body:fd});
    showResult("voiceResult", await res.json());
  } catch(e) { showError("voiceResult", "Cannot connect to server."); }
}
