const API = "http://localhost:5000";

async function loadDashboard() {
  try {
    const res   = await fetch(`${API}/api/stats`);
    const stats = await res.json();

    document.getElementById("totalScans").textContent  = stats.total_scans  || 0;
    document.getElementById("totalThreats").textContent= stats.total_threats|| 0;
    document.getElementById("totalSafe").textContent   = stats.total_safe   || 0;
    document.getElementById("threatRate").textContent  = `${stats.threat_rate||0}%`;

    const tbody  = document.getElementById("scansBody");
    const recent = stats.recent_scans || [];
    tbody.innerHTML = "";

    recent.forEach(scan => {
      const row   = document.createElement("tr");
      row.className = scan.is_threat ? "threat-row" : "safe-row";
      row.innerHTML = `
        <td>${scan.timestamp}</td>
        <td>${scan.scan_type?.toUpperCase()}</td>
        <td>${scan.verdict}</td>
        <td>${scan.risk_score}%</td>`;
      tbody.appendChild(row);
    });

  } catch(e) {
    console.error("Dashboard load failed:", e);
  }
}

loadDashboard();
setInterval(loadDashboard, 10000); // Auto-refresh every 10 seconds
